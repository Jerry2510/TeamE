﻿namespace TeamE
{
    public static class Startup
    {
        public static void ConfigureMiddleware(this IApplicationBuilder app)
        {
            app.UseOnUrl("/index", async context =>
            {
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "NewFolder1", "index.html");
                if (File.Exists(filePath))
                {
                    context.Response.ContentType = "text/html";
                    var htmlContent = await File.ReadAllTextAsync(filePath);
                    await context.Response.WriteAsync(htmlContent);
                }
                else
                {
                    context.Response.StatusCode = 404;
                }
            }, false);

            app.UseOnUrl("/register", async context =>
            {
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "NewFolder1","login&register.html");
                if(File.Exists(filePath))
                {
                    context.Response.ContentType = "text/html";
                    var htmlContent = await File.ReadAllTextAsync(filePath);
                    await context.Response.WriteAsync(htmlContent);
                }
                else
                {
                    context.Response.StatusCode = 404;
                }
            },false);
            app.UseOnUrl("/books", async context =>
            {
                //var paths = context.Request.Path.ToString().Split("/");

                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "NewFolder1", "Books.html");
                if (File.Exists(filePath))
                {
                    context.Response.ContentType = "text/html";
                    var htmlContent = await File.ReadAllTextAsync(filePath);
                    await context.Response.WriteAsync(htmlContent);
                }
                else
                {
                    context.Response.StatusCode = 404;
                }
            }, false);

            app.UseOnUrl("/authors", async context =>
            {
                //var paths = context.Request.Path.ToString().Split("/");

                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "NewFolder1", "Authors.html");
                if (File.Exists(filePath))
                {
                    context.Response.ContentType = "text/html";
                    var htmlContent = await File.ReadAllTextAsync(filePath);
                    await context.Response.WriteAsync(htmlContent);
                }
                else
                {
                    context.Response.StatusCode = 404;
                }
            }, false);
            app.UseOnUrl("/authordetails", async context =>
            {
                var paths = context.Request.Path.ToString().Split("/");

                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "NewFolder1", "AuthorDetails.html");
                if (File.Exists(filePath))
                {
                    context.Response.ContentType = "text/html";
                    var htmlContent = await File.ReadAllTextAsync(filePath);
                    await context.Response.WriteAsync(htmlContent);
                }
                else
                {
                    context.Response.StatusCode = 404;
                }
            }, false);
        }
    }
}
